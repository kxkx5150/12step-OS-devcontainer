#ifndef _ETHERDRV_H_INCLUDED_
#define _ETHERDRV_H_INCLUDED_

#define ETHERDRV_DEVICE_NUM 1
#define ETHERDRV_CMD_USE  'u' /* イーサネット・ドライバの使用開始 */
#define ETHERDRV_CMD_SEND 's' /* イーサネットへのフレーム出力 */

#endif
