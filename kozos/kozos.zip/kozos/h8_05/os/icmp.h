#ifndef _ICMP_H_INCLUDED_
#define _ICMP_H_INCLUDED_

#define ICMP_CMD_RECV     'r' /* ICMPパケットの受信 */
#define ICMP_CMD_SEND     's' /* ICMPパケットの送信 */

#endif
